import pymongo
from math import fsum
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from flask import Flask, request, jsonify, redirect, Response
from bson import json_util
from bson.objectid import ObjectId
import json
import uuid
import time
import os

# Connect to our local MongoDB
mongodb_hostname = os.environ.get("MONGO_HOSTNAME","localhost")
client = MongoClient('mongodb://'+mongodb_hostname+':27017/')

# Choose database
db = client['DSMarkets']

# Choose collections
products= db['Products']
users = db['Users']

total_cost = {"cost":0}

# Initiate Flask App
app = Flask(__name__)

users_sessions = {}
admin_sessions = {}

# This is a function which generates an uuid for each username given as argument
def create_session(email):
    user_uuid = str(uuid.uuid1())
    users_sessions[user_uuid] = (email, time.time())
    return user_uuid  

# Validation that the user has logged in
def is_session_valid(user_uuid):
    return user_uuid in users_sessions

def admin_create_session(email):
    user_uuid = str(uuid.uuid1())
    admin_sessions[user_uuid] = (email, time.time())
    return user_uuid  

# Validation that the user has logged in
def admin_is_session_valid(user_uuid):
    return user_uuid in admin_sessions


# ΕΡΩΤΗΜΑ 1: Δημιουργία χρήστη
@app.route('/create-user', methods=['POST'])
def createUser():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    # if not "username" in data or not "password" in data or not "email" in data:
        # return Response("Information incomplete",status=500,mimetype="application/json")
    
    if users.find({"username":data["username"]}).count() == 0 : 

        # Add user to the 'users' collection
        user = { "username": data['username'], "password": data['password'], "email": data['email'], "category":data['category'], "shopping_cart":[], "orderHistory":[]}
        users.insert(user)
        # Μήνυμα επιτυχίας
        return Response(data['username'] + " was added to the MongoDB", status=200, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS
    # Διαφορετικά, αν υπάρχει ήδη κάποιος χρήστης με αυτό το username.
    else:
        # Μήνυμα λάθους (Υπάρχει ήδη κάποιος χρήστης με αυτό το username)
        return Response("A user with the given username already exists", status=400, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS    


    # Έλεγχος δεδομένων username / password
    # Αν δεν υπάρχει user με το username που έχει δοθεί. 
    # Να συμπληρώσετε το if statement.

    # ΕΡΩΤΗΜΑ 2: Login στο σύστημα
@app.route('/login', methods=['POST'])
def login():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "username" in data or not "password" in data or not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")


    # Έλεγχος δεδομένων username / password
    # Αν η αυθεντικοποίηση είναι επιτυχής. 
    # Να συμπληρώσετε το if statement.
    if users.find_one({"username": data['username'], "password": data['password'], "email": data['email'], "category":data['category']}):
        if data['category'] == 'user':
            user_uuid = create_session({"email": data['email']})
            res = {"uuid": user_uuid, "email": data['email']}
            return Response(json.dumps(res), status=200, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS

        elif data['category'] == 'administrator':
            user_uuid = admin_create_session({"email":data['email']})
            res = {"uuid": user_uuid, "email":data['email']}
            return Response(json.dumps(res), status=200, mimetype='application/json')

    # Διαφορετικά, αν η αυθεντικοποίηση είναι ανεπιτυχής.
    else:
        # Μήνυμα λάθους (Λάθος username ή password)
        return Response("Wrong username or password.", status=400, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS

# ΕΡΩΤΗΜΑ 3: Επιστροφή  
@app.route('/getProductCategory', methods=['GET'])
def get_productCategory():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "category" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')

    if is_session_valid(uuid):

        productcategory = products.find({"category":data['category']}).sort([("price", pymongo.ASCENDING)])

        if products.find_one({"category":data['category']}):
            productc = json.loads(json_util.dumps(productcategory))
            return Response(json.dumps(productc), status=200, mimetype='application/json')

        else:
            return Response("Error:No product was found with either the given category!!!!", status=400, mimetype="application/json")
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')

@app.route('/getProductName', methods=['GET'])
def get_productName():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "name" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')

    if is_session_valid(uuid):

        productname = products.find({"name":data['name']}).sort([("description", pymongo.ASCENDING), ("category", pymongo.ASCENDING), ("price", pymongo.ASCENDING), ("unique_id", pymongo.ASCENDING)])
        
        if products.find_one({"name":data['name']}):
           productn = json.loads(json_util.dumps(productname))
           return Response(json.dumps(productn), status=200, mimetype='application/json')

        else:
             return Response("Error:No product was found with the given name!!!!", status=400, mimetype="application/json")
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')

@app.route('/getProductID', methods=['GET'])
def get_productID():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "unique_id" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')

    if is_session_valid(uuid):

        productid = products.find_one({"unique_id":data['unique_id']})

        if products.find_one({"unique_id":data['unique_id']}):
            productu = json.loads(json_util.dumps(productid))
            return Response(json.dumps(productu), status=200, mimetype='application/json')

        else:
             return Response("Error:No product was found with the given unique_id code!!!!", status=400, mimetype="application/json")
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')


@app.route('/insertProduct', methods=['PATCH'])
def insert_product():

    global total_cost
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "unique_id" in data or not "stock" in data or not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')

    if is_session_valid(uuid):
        product_data = products.find_one({"unique_id":data['unique_id']})
        if products.find_one({"unique_id":data['unique_id']}):
            if data['stock'] <= product_data['stock']:
                productu = json.loads(json_util.dumps(product_data))

                cost = data['stock'] * productu['price']
              
                for cos in total_cost:
                    total_cost[cos] = total_cost[cos] + cost


                product = {"name":productu['name'], "description":productu['description'], "price":productu['price'], "category":productu['category'], "unique_id":data['unique_id'], "stock":data['stock']}

                res = users.update_one({"email":data['email']},{"$push": { "shopping_cart" : {"name":productu['name'], "description":productu['description'], "price":productu['price'], "category":productu['category'], "unique_id":data['unique_id'], "stock":data['stock']}}})
                res1 = users.update_one({"email":data['email']},{"$push": { "orderHistory" : {"name":productu['name'], "description":productu['description'], "price":productu['price'], "category":productu['category'], "unique_id":data['unique_id'], "stock":data['stock']}}})


                return Response("The product which was inserted into the shopping_cart is:" + str(product), status=200, mimetype='application/json')
            else:
                return Response("Error:The ideal stock that you entered is above the maximum value of the available stock in our e-shop!!!!", status=400, mimetype="application/json")

        else:
             return Response("Error:No product was found with the given unique_id code!!!!", status=400, mimetype="application/json")
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')
    
@app.route('/showProduct', methods=['GET'])
def show_product():

    global total_cost
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")
        

    uuid = request.headers.get('authorization')
    global total_cost

    if is_session_valid(uuid): 

        shop_list = users.find_one({"email":data['email']})     
        shopdata = json.loads(json_util.dumps(shop_list))

        return Response("The products which were inserted into the shopping_cart are:" + str(shopdata['shopping_cart']) + " and the total price the user has to pay for all the products is: " + str(total_cost), status=200, mimetype='application/json')
            
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')

@app.route('/deleteProduct', methods=['DELETE'])
def delete_product():

    global total_cost
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "unique_id" in data or not "stock" in data or not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')
    global total_cost

    if is_session_valid(uuid):
        product_data = products.find_one({"unique_id":data['unique_id']})
        if products.find_one({"unique_id":data['unique_id']}):
            if data['stock'] <= product_data['stock']:

                productu = json.loads(json_util.dumps(product_data))

                cost = productu['price'] * data['stock']

                for k in total_cost:
                    total_cost[k] = total_cost[k] - cost

                product = {"name":productu['name'], "description":productu['description'], "price":productu['price'], "category":productu['category'], "unique_id":data['unique_id'], "stock":data['stock']}

                res = users.update_one({"email":data['email']},{"$pull": { "shopping_cart" : {"name":productu['name'], "description":productu['description'], "price":productu['price'], "category":productu['category'], "unique_id":data['unique_id'], "stock":data['stock']}}})
                res1 = users.update_one({"email":data['email']},{"$pull": { "orderHistory" : {"name":productu['name'], "description":productu['description'], "price":productu['price'], "category":productu['category'], "unique_id":data['unique_id'], "stock":data['stock']}}})

                return Response("The product has been deleted and the current total price is:" + str(total_cost), status=200, mimetype='application/json')
            else:
                return Response("Error:The product you are trying to delete from the cart does not exist!!!!", status=400, mimetype="application/json")

        else:
            return Response("Error:No product was found with the given unique_id code!!!!", status=400, mimetype="application/json")
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')

@app.route('/purchaseProduct', methods=['POST'])
def purchase_product():
    global total_cost
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "card_code" in data or not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')

    if is_session_valid(uuid):
        
        if len(data['card_code']) == 16 and users.find_one({"email":data['email']}):


            product_data = users.find_one({"email":data['email']})   
            productu = json.loads(json_util.dumps(product_data))

            return Response("The receipt of the products bought is:" + str(productu['orderHistory']) +  " with a total value of:" + str(total_cost), status=200, mimetype='application/json')
        else:
            return Response("Error:The length of the card_code is not within the appropriate limits!!!!", status=400, mimetype="application/json")
    else:
        return Response("There is not a user with this email(user has not been authenticated).", status=401, mimetype='application/json')    


@app.route('/remove-user', methods=['DELETE'])
def removeUser():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "username" in data or not "password" in data or not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")
        
    if users.find_one({"email":data["email"]}): 
            # Add user to the 'users' collection
        user = { "username": data['username'], "password": data['password'], "email": data['email']}
        users.remove(user)
            # Μήνυμα επιτυχίας
        return Response("The user has been deleted from the mongodb", status=200, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS
        # Διαφορετικά, αν υπάρχει ήδη κάποιος χρήστης με αυτό το username.
    else:
            # Μήνυμα λάθους (Υπάρχει ήδη κάποιος χρήστης με αυτό το username)
        return Response("The user does not exist in mongodb", status=400, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS 

@app.route('/adminInsertProduct', methods=['POST'])
def adminInsertProduct():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "email" in data or not "name" in data or not "category" in data or not "stock" in data or not "description" in data or not "price" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")
        
    uuid = request.headers.get('authorization')

    if admin_is_session_valid(uuid):
        
        if users.find_one({"email":data["email"]}): 
            # Add user to the 'users' collection
            product = {"name": data['name'], "category": data['category'], "stock": data['stock'], "description":data['description'], "price":data['price']}
            res = products.insert(product)
            # Μήνυμα επιτυχίας
            return Response("The admin inserted the product into the mongo database!!!!", status=200, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS
        # Διαφορετικά, αν υπάρχει ήδη κάποιος χρήστης με αυτό το username.
        else:
            # Μήνυμα λάθους (Υπάρχει ήδη κάποιος χρήστης με αυτό το username)
            return Response("The user does not exist in mongodb", status=400, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS 
    else:
        return Response("The administrator has not been registered!!!!", status=400, mimetype='application/json')
    
@app.route('/getObjectId', methods=['GET'])
def getObjectId():
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "email" in data or not "name" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')

    if admin_is_session_valid(uuid):

        res = products.find_one({"name":data['name']})
        result = json.loads(json_util.dumps(res))
        return Response(json.dumps(result), status=200, mimetype='application/json')
    else:
        return Response("The administrator has not been registered!!!!", status=400, mimetype='application/json')

@app.route('/adminRemoveProduct', methods=['DELETE'])
def adminRemoveProduct():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "_id" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")
        
    uuid = request.headers.get('authorization')

    if admin_is_session_valid(uuid):

        productdata = products.find_one({"_id":ObjectId(data["_id"])})

        
        if products.find_one({"_id":ObjectId(data["_id"])}):

            products.remove(productdata)
            
            
            # Μήνυμα επιτυχίας
            return Response("The admin removed the product from the mongo database!!!!", status=200, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS
        # Διαφορετικά, αν υπάρχει ήδη κάποιος χρήστης με αυτό το username.
        else:
            # Μήνυμα λάθους (Υπάρχει ήδη κάποιος χρήστης με αυτό το username)
            return Response("The product does not exist in mongodb", status=400, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS 
    else:
        return Response("The administrator has not been registered!!!!", status=400, mimetype='application/json')

    
@app.route('/adminUpdateProduct', methods=['PATCH'])
def adminUpdateProduct():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "_id" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")
        
    uuid = request.headers.get('authorization')

    if admin_is_session_valid(uuid):

        productdata = products.find_one({"_id":ObjectId(data["_id"])})

        
        if products.find_one({"_id":ObjectId(data["_id"])}):

            if "name" in data:
                products.update_one({"name":productdata['name']},{"$set":{"name":data['name']}})

            if "price" in data:
                products.update_one({"price":productdata['price']},{"$set":{"price":data['price']}})

            if "description" in data:
                products.update_one({"description":productdata['description']},{"$set":{"description":data['description']}})

            if "stock" in data:
                products.update_one({"stock":productdata['stock']},{"$set":{"stock":data['stock']}})
            
            
            # Μήνυμα επιτυχίας
            return Response("The admin updated the product from the mongo database!!!!", status=200, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS
        # Διαφορετικά, αν υπάρχει ήδη κάποιος χρήστης με αυτό το username.
        else:
            # Μήνυμα λάθους (Υπάρχει ήδη κάποιος χρήστης με αυτό το username)
            return Response("The product does not exist in mongodb", status=400, mimetype='application/json') # ΠΡΟΣΘΗΚΗ STATUS 
    else:
        return Response("The administrator has not been registered!!!!", status=400, mimetype='application/json')


    
            

# Εκτέλεση flask service σε debug mode, στην port 5000. 

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)